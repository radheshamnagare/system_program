/*Required header files*/
using namespace std;
#include<iostream>
#include<string>
#include<cstring>
#include<stdlib.h>

/*error_translator class include various methods & variable declaration for meaningful information*/
class error_translation{
   
   /*declaration of variable*/
   private :
    string _8bit[8] ={"al","cl","dl","bl","ah","ch","dh","bh"};
  	string _16bit[8] = {"ax","cx","dx","bx","sp","bp","si","di"};
  	string _32bit[8] = {"eax","ecx","edx","ebx","esp","ebp","esi","edi"};
    string dt[4]={"db","dw","dd","dq"};
    string bdt[4]={"resb","resw","resd","resq"};
  	string instr[8]={"add","and","div","mov","mul","or","xor","xnor"};
  	string jmp[6]={"jmp","jz","jnz","push","INC","DEC"};
    char buff[80],t1[10],t2[10],t3[20];
    int ln,f;
    
   public:
    /*structure declarion for collecting symbol*/
    struct sym{
        string sym;
        struct sym *next;
    }*s; 
    /*declaration of structure for collecting lables*/
    struct lbls{
      string instr;
      string l;
      int ln;
      struct lbls *next;
    }*lb;
    /*public constructor of error_translation class for initilize member of class & initilize methods*/
   	error_translation(){
      f=0;
      ln = 0;
      init(&s);
      init(&lb);
   	}
    /*template type init() for initilize structure object to null*/
   	template <class x>
   	void init(x **s){
   		*s=NULL;
   	}
    /*creating node of structure sym type*/
   	struct sym * node(string sy){
   		struct sym *N;
   		N = new sym;
   		N->sym = sy;
        N->next = NULL;
   	}
    /*creating node of structure lbls type*/
   	struct lbls * lNode(string l,string s,int ln){
   		lbls *N = new lbls;
   		N->instr = l;
   		N->l = s;
   		N->ln=ln;
   		N->next = NULL;
   	}
    /*template type method for creating list data structure for sym & lbls structure*/
   	template <class y>
   	y * create_sym(y *s,y *N){
         y *t;
            if(s==NULL)
            	s=N;
            else{
            	for(t=s;t->next!=NULL;t=t->next);
            		t->next = N;
            }
   	}
    /*Read_instr() start to read file line by line & decision further process*/
  	void Read_instr(FILE *fp){

  		  while(fgets(buff,80,fp)!=NULL){
               sscanf(buff,"%s %s %s",t1,t2,t3);
               ln++;
               /*checking each section type in file*/
               if(strcmp(t1,"section")==0 && strcmp(t2,".data")==0){
               	f =1;
               	continue;
               }
               else if(strcmp(t1,"section")==0 && strcmp(t2,".bss")==0){
                 f=2;
                 continue; 
               }
               else if(strcmp(t1,"section")==0 && strcmp(t2,".text")==0){
               	 f=3;
               	 continue;
               }

               if(f==1){
                   _const(t1,t2);   
               }
               else if(f==2){
                   _vari(t1,t2); 
               }
               else if(f==3){
               	if(strcmp(t1,"global")==0)
               		continue;
                   if(strlen(t1)!=0 && strlen(t2)!=0){
                   	  
                   	  	
                   	  if(is_lbl(t1,t2)){
                   	  	sym *newnode;
                        newnode = node(t1); // storing the lables
                        s = create_sym(s,newnode);
                   	  	continue;
                   	  }	

                   	  else if(!is_instr(t1))
        	           cout<<"\nIN SECTION .DATA "<<"\nError :"<<t1<<" invalid instruction near line"<<ln<<endl;
                   	 /*checking the instruction type*/
                   	  if(jmp_instr(t1,t2));
                   	  else if(reg_to_reg(t2));
                   	  else if(reg_imm(t2));
                   	  else if(reg_to_mem(t2));
                   	  else
                   	  	cout<<"\nIN SECTION .DATA "<<"\nError :"<<t2<<" invalid nmemonic operand near line "<<ln<<endl;
                   }
               }
                /*clearing the string*/
                 memset(t1,'\0',sizeof(t1));
                 memset(t2,'\0',sizeof(t2));
                 memset(t3,'\0',sizeof(t3));

  		  }
                 check_lbl();
  	}
    /*check_lbl() checking the object is lable also it valid or not*/
    void check_lbl(){
    	struct lbls *t;
    	struct sym *t1;
        int f;  
    	for(t = lb;t!=NULL;t=t->next){
    		f=1;
           for(t1=s;t1!=NULL;t1=t1->next){
               if(t1->sym == lb->l)
               	f=0;
           }  
           if(f==1)
           	cout<<"\nIN SECTION .DATA"<<"\nError :"<<t->instr<<" invalid instruction "<<t->l<<" near line "<<ln;
    	}

    }
    /*is_jmp_instr() checking string of value is jump instruction or not*/
    int is_jmp_instr(string op){
    	for(int i=0;i<6;i++){
    		if(op == jmp[i])
    			return 1;
    	}
    	return 0;
    }
    /*checking the jump instruction is valid or not*/
  	int jmp_instr(string instr,string op){
      /*checking further condition*/ 
  	if(is_jmp_instr(instr)){	
  		if(is_reg(op)!=-1)
  			return 1;
  		else if(is_hex(op)!=0)
  			return 1;
  		else if(is_recored(op)!=0)
  			return 1;
  		else if(is_int(op)!=0)
  			return 1;
        else
        	{ //storing the second operand of jmp instruction
        		struct lbls *newnode;
        		newnode = lNode(instr,op,ln);
               lb = create_sym(lb,newnode);
        	}
        	return 1;
     }
       return 0; 
  	}
    /*checking the lable is valid or not*/
    int is_lbl(string l,string colon){
         if(colon == ":"){
          sym *newnode;
          newnode = node(l); //storing the lable
          s = create_sym(s,newnode);	
          return 1;
         }
        return 0; 
    }
    /*checking the register valid or not*/
    int is_reg(string r){

   	  for(int i=0;i<8;i++){ 
          if(_8bit[i] == r) //checking 8 bit reg
          	return i;
          else if(_16bit[i] == r) // checking 16 bit reg
          	return i;
          else if(_32bit[i] == r) // checking 32 bit reg
          	return i;
   	  }

   	  return -1;
   }
    /*checking the operand is hexadecimal value or not*/
   int is_hex(string s){
      if(isdigit(s.front()) && s.back() == 'h' || s.back() == 'H')
      return 1;

     return 0;    
   }
   /*checking value string is numerical or not*/
   int is_int(string no){
       for(int i=0;i<no.size();i++){
       	 if(!isdigit(no[i]))
       	 	return 0;
       }
      return 1; 
  }
  /*checking instruction is type of register to memory*/
   int reg_to_mem(string rm){
       int p = rm.find(',');
       string v = rm.substr(p+1);

       if(v.size()!=0){
       	 v.erase(0,1);
       	 v.pop_back();
       }
         if(is_reg(rm.substr(0,p))!=-1 && is_reg(v)!=-1)//both operand is register or not
             return 1;
           /*checking one operand register & unother is symbol*/
         else if(is_reg(rm.substr(0,p))!=-1 && is_recored(v)!=0)
            return 1;
          /*checking one operand register & unother is hex value*/
         else if(is_reg(rm.substr(0,p))!=-1 && is_hex(v)!=0)
      	    return 1;
          /*checking one operand register & unother is numeric value*/
         else if(is_reg(rm.substr(0,p))!=-1 && is_int(v)!=0)
            return 1;
     return 0;
  }
  /*checking instruction is type of register to immidiate value*/
   int reg_imm(string op){
        int p = op.find(',');
        /*checking the instruction is to immidiate hex*/
        if(is_reg(op.substr(0,p))!=-1 && is_hex(op.substr(p+1))!=0)
         return 1;
       /*checking the instruction is immidiate to integer value*/
        else if(is_reg(op.substr(0,p))!=-1 && is_int(op.substr(p+1))!=0)
         return 1;

         return 0; 	  
    }
    /*checking the instruction is regieter to immidiate*/
  	int reg_to_reg(string op){
        int p = op.find(',');
        /*both operand is register to register*/
        if(is_reg(op.substr(p+1))!=-1 && is_reg(op.substr(0,p))!=-1){
        		return 1;
        }
        return 0;
  	}
    /*checking the valid instruction or not*/
    int is_instr(string ins){
    	if(is_jmp_instr(ins))
    		return 1;
    	for(int i=0;i<8;i++){
    		if(ins == instr[i])
    			return 1;
    	}
      return 0;	
    }
    /*checking the .bss section variable valid or not*/
    void _vari(string nm,string typ){
      if(is_recored(nm)!=0 && is_valid_dbt(typ)!=0)
      	cout<<"\nIN SECTION .BSS "<<"\nError :"<<nm<<" redeclaration near line "<<ln<<endl;
      if(!is_valid_dbt(typ))
      	cout<<"\nIN SECTION .BSS"<<"\nError :"<<typ<<" invalid type near line "<<ln<<endl;
      if(!is_recored(nm)){ // checking the stored symbol
          sym *newnode;
          newnode = node(nm);
          s = create_sym(s,newnode);
      }
    }
    /*checking the .data section constant is valid or not*/
  	void _const(string nm,string op1){
  		if(is_recored(nm)!=0 && is_valid_d(op1)!=0)
  			cout<<"\nIN SECTION .DATA"<<"\nERROR : "<<nm<<" redeclaration near line "<<ln<<endl;
        
        if(!is_valid_d(op1))
          cout<<"\nIN SECTION .DATA"<<"\nERROR :"<<op1<<" invalid type near line"<<ln<<endl;  
        
        if(!is_recored(nm)){//checking the storing symbol
          sym *newnode;
          newnode = node(nm);
          s = create_sym(s,newnode);
        }
  	}
    /*checking the symbol is store symbol*/
    int is_recored(string sym){
    	struct sym *t;
    	for(t=s;t!=NULL;t=t->next){
    		if(t->sym==sym)
    			return 1;
    	}

    	return 0;
    }
    /*checking data type in .bss section*/
    int is_valid_dbt(string d){
    	for(int i=0;i<4;i++){
    		if(d==bdt[i])
    			return 1;
    	}
    	return 0;
    }
    /*checking data type in .data section is valid or not*/
    int is_valid_d(string d){
         for(int i=0;i<4;i++)
         {
         	if(d==dt[i])
         		return 1;
         }
         return 0;
    }

}et;//object of class
/*driver code*/
int main(int argc, char const *argv[])
{
  /*variable declaration*/
	FILE *fp;
	string fname;

	system("clear");

	cout<<"Enter the file name :";
	cin>>fname;

	fp =  fopen(fname.c_str(),"r");
  //checking the file object valid or not
	if(fp == NULL){
		cout<<"Error to reading file";
		exit(0);
	}
    et.Read_instr(fp); //reading file line by line

	return 0;
}