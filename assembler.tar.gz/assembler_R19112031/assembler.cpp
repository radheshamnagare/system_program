/*Required header files*/
using namespace std;
#include<iostream>
#include<iomanip>
#include<string>
#include<vector>
#include<cmath>
#include<string.h>
#include<stdlib.h>
/*defination of namespace of global vector*/
namespace instr{
  vector < pair <string,string> > v1;
  vector < pair <string,string> > v2;
};
/*use namespace in programm*/
using namespace instr;
/*defination of register class for defining various methods & declaration of variable to generate 
 meaninful information*/
class _register
{

   public :
     /*declaration of variable*/
    string _8bit[8] ={"al","cl","dl","bl","ah","ch","dh","bh"};
    string _16bit[8] = {"ax","cx","dx","bx","sp","bp","si","di"};
    string _32bit[8] = {"eax","ecx","edx","ebx","esp","ebp","esi","edi"};

  public :
  /*checking operand is register or not*/        
  int is_reg(string r)
  {

      for(int i=0;i<8;i++)
      {
          if(_8bit[i] == r)//checking 8 bit register
            return i;
          else if(_16bit[i] == r) // checking 16 bit register
            return i;
          else if(_32bit[i] == r) // checking 32 bit register
            return i;
      }

      return -1;
   } 
   /*checking which type of bit register*/
   int _reg(string r)
   {
     
      for(int i=0;i<8;i++)
      {
          if(_8bit[i] == r)
            return 8;
          else if(_16bit[i] == r)
            return 16;
          else if(_32bit[i] == r)
            return 32;
      }

      return -1;   
   } 

};
/*defination of instructor class for defining various method & variable to generating 
 meaningful information*/
class instrct : public _register
{

   private : 
      /*declaration of variable*/
      FILE **fp;
      string rg,r,reg;
      char buff[80],t1[10],t2[10],t3[10];
   public :
      /*public constructor to initilize object*/  
      instrct(){

        fp = (FILE **)malloc(3*sizeof(FILE*));
      } 
      /*conversion of hexadecimal string to decimal string*/
      long hex_deci(string no){
       long num=0;
       int p=0;
       cout<<std::resetiosflags(std::ios::hex);
        for(int i = no.length()-1;i>=0;i--){
                
                if(no[i] == 'A')
                  num+=(10*pow(16,p++));
                else if(no[i] == 'B')
                  num+=(11*pow(16,p++));
                else if(no[i] == 'C')
                  num+=(12*pow(16,p++));
                else if(no[i] == 'D')
                  num+=(13*pow(16,p++));
                else if(no[i] == 'E')
                  num+=(14*pow(16,p++));
                else if(no[i] == 'F')
                  num+=(15*pow(16,p++));
                else
                 num+= stoi(string(1,no[i])) * pow(16,p++);
                 
                
        }
           
        return num;
      }
       /*register to register type instructor*/
      string instr_rtor(string instr,string r1,string r2){
             
          fp[0] = fopen("instr_rtor.text","r");
          if(fp[0] == NULL)
           perror("error to open instr_rtor");

           else
           {
             if(_reg(r1) == 8 && _reg(r2) ==8)
             {
              rg = "r/m8";
              r = "r8";
             }
             if(_reg(r1) == 16 && _reg(r2) ==16)
             {
              rg = "r/m16";
              r = "r16";
             }
             if(_reg(r1) == 32 && _reg(r2) ==32)
             {
              rg = "r/m32";
              r = "r32";
             }
              while(fgets(buff,80,fp[0])!=NULL){
                    
                    memset(t1,'\0',sizeof(t1));
                    memset(t2,'\0',sizeof(t2));
                    memset(t3,'\0',sizeof(t3));

                    sscanf(buff,"%s %s %s",t1,t2,t3);
                    
                    if(strcmp(t1,"start") ==0 && strcmp(t2,":") ==0 && strcmp(t3,instr.c_str())==0)
                    {
                             while(fgets(buff,80,fp[0])!=NULL)
                             {
                                  memset(t1,'\0',sizeof(t1));
                                  memset(t2,'\0',sizeof(t2));
                                  memset(t3,'\0',sizeof(t3));
                                  sscanf(buff,"%s %s %s",t1,t2,t3);
                                  if(strcmp(t1,":") ==0 && strcmp(t2,"end") ==0 && strcmp(t3,instr.c_str())==0)
                                   break;      
                                  if(strcmp(t1,rg.c_str()) ==0 && strcmp(t2,r.c_str()) ==0 )
                                  return t3;     
                             }
                       break;
                    }

              }
           }   

           return string("");         
      }
       /*register to memory type instructor*/
      string instr_rtom(string instr,string r1,string r2){
           
       fp[2] = fopen("instr_rtorm.text","r");
          if(fp[2] == NULL)
           perror("error to open instr_rtorm");

           else
           {
             if(_reg(r1) == 8 && _reg(r2) ==8)
             {
              rg = "r8";
              r = "r/m8";
             }
             else if(_reg(r1) == 16 && _reg(r2) ==16)
             {
              rg = "r16";
              r = "r/m16";
             }
             else if(_reg(r1) == 32 && _reg(r2) ==32)
             {
              rg = "r32";
              r = "r/m32";
             }
             else if(stol(r2)<=255 && _reg(r1) == 8){
              rg = "r8"; 
              r = "r/m8";
             }
            else if(stol(r2)>255 && stol(r2)<=65535 && _reg(r1) == 16){
              rg = "r16";
              r = "r/m16";  
            }
            else if(stol(r2)>65535 && stol(r2)<=2147483647 && _reg(r1) == 32){
             rg = "r32";
             r = "r/m32";
            }
              while(fgets(buff,80,fp[2])!=NULL){
                    
                    memset(t1,'\0',sizeof(t1));
                    memset(t2,'\0',sizeof(t2));
                    memset(t3,'\0',sizeof(t3));

                    sscanf(buff,"%s %s %s",t1,t2,t3);
                    
                    if(strcmp(t1,"start") ==0 && strcmp(t2,":") ==0 && strcmp(t3,instr.c_str())==0)
                    {
                             while(fgets(buff,80,fp[2])!=NULL)
                             {
                                  memset(t1,'\0',sizeof(t1));
                                  memset(t2,'\0',sizeof(t2));
                                  memset(t3,'\0',sizeof(t3));
                                  sscanf(buff,"%s %s %s",t1,t2,t3);
                                  if(strcmp(t1,":") ==0 && strcmp(t2,"end") ==0 && strcmp(t3,instr.c_str())==0)
                                   break;      
                                  if(strcmp(t1,rg.c_str()) ==0 && strcmp(t2,r.c_str()) ==0 )
                                  return t3;     
                             }
                       break;
                    }

              }
           }   

           return string("");    
      }
      /*register to immidiate type of instructor*/
      string instr_rtoimm(string instr,string rg,long bit){
              
          if(_reg(rg) == 8)
            reg == "r/m8";
          else if(_reg(rg) == 16)
            reg = "r/m16";
          else if(_reg(rg) == 32)
            reg = "r/m32";

            if(bit<=255) 
             r = "imm8";
            else if(bit>255 && bit<=65535)
             r = "imm16";  
            else if(bit>65535 && bit<=2147483647)
             r = "imm32";
          
          fp[1] = fopen("instr_imm.text","r");
          if(fp[1] == NULL)
           perror("error to open instr_rtor");

           else
           {
             
              while(fgets(buff,80,fp[1])!=NULL){
                    
                    memset(t1,'\0',sizeof(t1));
                    memset(t2,'\0',sizeof(t2));
                    memset(t3,'\0',sizeof(t3));

                    sscanf(buff,"%s %s %s",t1,t2,t3);
                    
                    if(strcmp(t1,"start") ==0 && strcmp(t2,":") ==0 && strcmp(t3,instr.c_str())==0)
                    {
                             while(fgets(buff,80,fp[1])!=NULL)
                             {
                                  memset(t1,'\0',sizeof(t1));
                                  memset(t2,'\0',sizeof(t2));
                                  memset(t3,'\0',sizeof(t3));
                                  sscanf(buff,"%s %s %s",t1,t2,t3);
                                  if(strcmp(t1,":") ==0 && strcmp(t2,"end") ==0 && strcmp(t3,instr.c_str())==0)
                                   break;      
                                  if((strcmp(t1,rg.c_str())==0 || strcmp(t1,reg.c_str()) ==0)
                                   && strcmp(t2,r.c_str()) ==0 )
                                  return t3;     
                             }
                       break;
                    }

              }
           }
             return string("");
      }
};
/*defination of translator class for various mathod defination & variable to 
 generating meaningfull information*/
class translator : public instrct
{

  private:
    /*declaration of variable*/
  	int f,cnt_data,cnt_bss,cnt_text,l;
    char buff[80];
  	char t1[10],t2[20],t3[20];
  	string mod_r_rm;
    /*declaration of structure for storing symbol*/
    struct sym{
        string s;
        string addr;
        struct sym *next;
    }*head;
    /*declaration of structure for storing information each line :lno , how_many_byte & lable*/
    struct line_byte{
       int lno;
       int bit;
       string lbl;   
       struct line_byte *next; 
    }*start;
  public :
  /*public constructor of translator class to initilize object & method*/
   translator(){
     f = 0;
     l = 0;
     cnt_data = 0;
     cnt_bss = 0;
     cnt_text = 0;
     init(&head);
     init(&start);
   }
   /*template type of init() to initilize object null*/
   template <class x>
   void init(x **head){
     *head = NULL;
   }
   /*creating node information of sym type*/
   struct sym * newNode(string s,string addr){
     struct sym *newnode;
        newnode = new sym;
        newnode->next = NULL;
        newnode->s = s;
        newnode->addr = addr;
      return newnode;  
   }
   /*creating list of information symbols */
   void insert_sym(struct sym **head,struct sym *N){
    struct sym *t;
      if(*head == NULL)
        *head = N;
      else{
        for(t=*head;t->next!=NULL;t=t->next);
         t->next = N; 
      }
   }
   /*creating node information of each line of structure line_byte*/
   struct line_byte* newNode(int lno ,int bit,string lbl){
        struct line_byte *N;
        N = new line_byte;
        N->next = NULL;
        N->lno = lno;
        N->bit = bit;
        N->lbl = lbl;

        return N;
   }
   /*creating list of each line information*/
   void insert(line_byte **start,struct line_byte *N){
         struct line_byte *t;
         if(*start ==  NULL)
           *start = N;
         else
         {
           for(t=*start;t->next!=NULL;t=t->next);
            t->next = N;
         }
   }
   /*converting binary string to hex */
   string toHex(string no){
    
    int hno = 0;
    int j = 0;
    std::stringstream stream;
       for(int i=no.length()-1;i>=0;i--){
          hno+= (pow(2,j++) * (no[i]-'0'));
       }
     stream<<uppercase<<std::hex<<hno;

      return string(stream.str());    
   }
   /*returning associate binary string*/
   string toBin(int no){
   	 if(no == 0)
   	 	return "000";
   	 else if(no == 1)
        return "001";
     else if(no == 2)
     	return "010";
     else if(no == 3)
     	return "011";
     else if(no == 4)
     	return "100";
     else if(no == 5)
        return "101";
     else if(no == 6)
        return "110";
     else if(no == 7)
        return "111";    
   }
   
   /*checking operand hax or not*/
   int is_hex(string s){
      if(s.back() == 'h' || s.back() == 'H')
      return 1;

     return 0;    
   }
    /*reading file line by line & checking instruction further*/
    void readL(FILE *fp){
      
          while(fgets(buff,80,fp)!=NULL){
               ++l; // increament line by one
               /*clear the array*/
               memset(t1,'\0',sizeof(t1));
               memset(t2,'\0',sizeof(t2));
               memset(t3,'\0',sizeof(t3));
               sscanf(buff,"%s %s %s",t1,t2,t3);
               //checking each section type
               if(strcmp(t1,"section")==0 && strcmp(t2,".data")==0){
                 f = 1;
                 cout<<"\t\t\t\t"<<t1<<t2<<endl;
                 continue;
               }
               if(strcmp(t1,"section")==0 && strcmp(t2,".bss")==0){
                 f = 2;
                 cout<<"\t\t\t\t"<<t1<<t2<<endl;
                 continue;
               }
               if(strcmp(t1,"section")==0 && strcmp(t2,".text")==0){
                 f = 3;
                 cout<<"\t\t\t\t"<<t1<<t2<<endl;
                 continue;
               }
                   /*decision to calling function section wise*/
                    if(f == 1)
                    {
                       if(strlen(t1)!=0 && strlen(t2)!=0 && strlen(t3)!=0)
                        constant(t1,t2,t3);
                    }

                    if(f == 2)
                    {
                        if(strlen(t1)!=0 && strlen(t2)!=0 && strlen(t3)!=0)
                        variable(t1,t2,t3);
                    }

                    if(f == 3)
                    {      

                           if(strcmp(t1,"global") ==0)
                            continue; 
                          // checking instruction type
                           if(is_lbl(t1,t2));
                           else if(jump_instr(t1,t2));
                           else if(push_instr(t1,t2));
                           else if(inc_dec_instr(t1,t2));
                           else if(reg_reg(t1,t2));
                           else if(reg_imm(t1,t2));
                           else if(reg_mem(t1,t2));
                           

                          
                    }

          }

    }
    /*return sum of two integer*/
     int sum(int a,int b){
       return (a+b);
     }
     /*checking inc,dec type instruction*/
    int inc_dec_instr(string instr,string reg){

       int r = is_reg(reg);
         
          if(r!=-1){

           cout<<uppercase<<setfill('0')<<setw(8)<<hex<<cnt_text<<"  ";
           cout<<std::resetiosflags(std::ios::hex);
              if(instr == "inc"){
                  if(reg.back() == 'x')
                  {
                    cout<<sum(40,r);
                    cnt_text+=1;
                  }
                  else if(reg.back() == 'l' || reg.back() == 'h')
                  {
                    cout<<"FEC"<<r;
                    cnt_text+=2;
                    insert(&start,newNode(l,2,"NA"));
                  }
              } 
              else if(instr == "dec"){
                  if(reg.back() == 'x'){
                    cout<<sum(48,r);
                    cnt_text+=1;
                    insert(&start,newNode(l,1,"NA"));
                  }
                  else if(reg.back() == 'l' || reg.back() == 'h'){
                    cout<<"FEC"<<(8+r);
                    cnt_text+=2;
                    insert(&start,newNode(l,2,"NA"));
                  }
              }  
              cout<<"\t\t\t"<<instr<<" "<<reg<<endl;
              return 1;
          }

         return 0;
    }
 /*return the  2's complement of number*/   
string _2complement(string op,int end){
  int sum  = 0,v;
  string b = "",r = "",_2c;
  char bit = '1';
  stringstream stream;
  struct line_byte *t;

 for(t=start;t!=NULL;t=t->next){
   if(t->lbl != op)
      continue;
   for(t=t;t!=NULL;t=t->next)
   {
     sum+=t->bit;
     if(t->lno == end)
     break;
   }
 }
  v = sum;
  
  while(sum>0){
   b.insert(0,to_string((sum%2)));
   sum/=2;
  }
  for(int i = b.length()-1;i>=0;i--)
  {
     if(b[i] == '1')
      b[i] = '0';
     else
      b[i] = '1';
  }
          mod_r_rm = "EB";
          stream<<setw(8)<<setfill('1')<<b;
          cnt_text+=2;
          
           b.clear();
           b  = stream.str();
   for(int i=b.length()-1;i>=0;i--)
   {
              if(b[i] == '1' && bit == '1')
              {
                _2c.insert(0,"0");
                bit  = '1'; 
              }
              else{
                _2c.insert(0,"1");
                bit = '0';
              }
     }
     
    return mod_r_rm+toHex(_2c.substr(0,4))+toHex("1000");
}
    /*checking jump type instructor*/
    int jump_instr(string instr,string op){
        
        if(instr == "jmp" || instr == "jz" || instr == "jnz"){
          insert(&start,newNode(l,2,"NA"));
          cout<<uppercase<<setfill('0')<<setw(8)<<hex<<cnt_text<<"  ";
          cout<<_2complement(op,l);
          cout<<"\t\t\t"<<instr<<" "<<op<<endl;
          return 1;
        }
       return 0; 
    }
    /*checking push type instruction */
    int push_instr(string instr,string op){
       
          string s = is_sym(op);
          std::stringstream stream;
          int r1 = is_reg(op);


          if(r1!=-1 && instr == "push")
          {
            cout<<uppercase<<setfill('0')<<setw(8)<<hex<<cnt_text<<" ";
            cnt_text+=1;
            cout<<"5"<<r1;
            cout<<"\t\t\t"<<instr<<" "<<op<<endl; 
            insert(&start,newNode(l,1,"NA"));
            return 1;
          }
          else if(instr == "push" && is_hex(op)!=0){
            cout<<uppercase<<setfill('0')<<setw(8)<<hex<<cnt_text<<" ";
            op.pop_back();
              if(op.length() <=2){
                cout<<"6A"<<bigIndian(op);
                cnt_text+=2;
                insert(&start,newNode(l,2,"NA"));
                cout<<"\t\t"<<instr<<" "<<op<<endl;
              }
              if(op.length() >2){
                cout<<"6A";
                cout<<setw(8)<<setfill('0')<<left<<bigIndian(op);
                cnt_text+=5;
                insert(&start,newNode(l,5,"NA"));
                cout<<"\t\t"<<instr<<" "<<op<<endl;
              }
              return 1;
          }
          else if(instr == "push" && is_num(op)!=0){
            cout<<uppercase<<setfill('0')<<setw(8)<<hex<<cnt_text<<"  ";
            cout<<"6A";
            stream<<uppercase<<std::hex<<stoi(op);
              if(op.length()<=2){
                cout<<bigIndian(stream.str());
                cnt_text+=2;
                insert(&start,newNode(l,2,"NA"));
                cout<<"\t\t\t"<<instr<<" "<<op<<endl;
              }
              if(op.length()>2){
                 cout<<setw(8)<<setfill('0')<<left<<bigIndian(stream.str());
                 cnt_text+=5;
                 insert(&start,newNode(l,5,"NA"));
                 cout<<"\t\t"<<instr<<" "<<op<<endl;
              }

              return 1;
          }
          else if(instr == "push" && s.length()!=0){
            cout<<uppercase<<setfill('0')<<setw(8)<<hex<<cnt_text<<"  ";
            cout<<std::resetiosflags(std::ios::hex)<<68<<"["<<s<<"]";
            cnt_text+=5;
            insert(&start,newNode(l,5,"NA"));
            cout<<"\t\t"<<instr<<" "<<op<<endl;

            return 1;
          }
            
            return 0;
    } 
    /*checking constant in .data section*/
    void constant(string t1,string t2,string t3)
    {
        int i;
        
         cout<<uppercase<<setfill('0')<<setw(8)<<hex<<cnt_data<<" ";

          if(t2.compare("db") ==0){
            std::stringstream stream;
            stream<<uppercase<<setw(8)<<setfill('0')<<std::hex<<cnt_data;
            insert_sym(&head,newNode(t1,stream.str()));  
            t3.erase(0,1);
            t3.pop_back();

               for(i=0;i<t3.length() && i<9;i++){
                  cout<<hex<<(int)t3[i];
                  cnt_data++;
               }
               cout<<"\t"<<t1<<" "<<t2<<" "<<t3<<endl;
               if(i<t3.length()){
                  cout<<setfill('0')<<setw(8)<<hex<<cnt_data<<" ";
                  for(i=i;i<t3.length();i++){
                    cout<<hex<<(int)t3[i];
                    cnt_data++;
                  }
               }
               cout<<endl;
          }
          else if(t2.compare("dw") ==0){
            std::stringstream stream;
            stream<<uppercase<<setw(8)<<setfill('0')<<std::hex<<cnt_data;
            insert_sym(&head,newNode(t1,stream.str()));
            cout<<left<<setw(4)<<setfill('0')<<hex<<stoi(t3);
            cout<<"\t\t\t"<<t1<<" "<<t2<<" "<<t3<<endl;
            cnt_data+=2;
          }
          else if(t2.compare("dd") ==0){
            std::stringstream stream;
            stream<<uppercase<<setw(8)<<setfill('0')<<std::hex<<cnt_data;
            insert_sym(&head,newNode(t1,stream.str()));
            cout<<left<<setw(4)<<setfill('0')<<hex<<stoi(t3);
            cout<<"\t\t\t"<<t1<<" "<<t2<<" "<<t3<<endl;
            cnt_data+=4;
          }
          else if(t2.compare("dq") ==0){
            std::stringstream stream;
            stream<<uppercase<<setw(8)<<setfill('0')<<std::hex<<cnt_data;
            insert_sym(&head,newNode(t1,stream.str()));
            cout<<left<<setw(4)<<setfill('0')<<hex<<stoi(t3);
            cout<<"\t\t\t"<<t1<<" "<<t2<<" "<<t3<<endl;
            cnt_data+=8;
          }

    }
    /*checking the variable in .bss section*/  
    void variable(string t1,string t2,string t3){
         cout<<uppercase<<setfill('0')<<setw(8)<<hex<<cnt_bss<<" ";
         
          if(t2.compare("resb") ==0)
          {
             std::stringstream stream;
             stream<<uppercase<<setw(8)<<setfill('0')<<std::hex<<cnt_bss;
             insert_sym(&head,newNode(t1,stream.str())); 
             cout<<"<res "<<setw(8)<<setfill('0')<<right<<(stoi(t3)*1)<<">";
             cout<<"\t\t"<<t1<<" "<<t2<<" "<<t3<<endl;
             cnt_bss+=stoi(t3);  
          } 
          else if(t2.compare("resw") ==0){
             std::stringstream stream;
             stream<<uppercase<<setw(8)<<setfill('0')<<std::hex<<cnt_bss;
             insert_sym(&head,newNode(t1,stream.str()));
             cout<<"<res "<<setw(8)<<setfill('0')<<(stoi(t3)*2)<<">";
             cout<<"\t\t"<<t1<<" "<<t2<<" "<<t3<<endl;
             cnt_bss+=(stoi(t3)*2);   
          }
          else if(t2.compare("resd") ==0){
             std::stringstream stream;
             stream<<uppercase<<setw(8)<<setfill('0')<<std::hex<<cnt_bss;
             insert_sym(&head,newNode(t1,stream.str()));
             cout<<"<res "<<setw(8)<<setfill('0')<<(stoi(t3)*4)<<">";
             cout<<"\t\t"<<t1<<" "<<t2<<" "<<t3<<endl;
             cnt_bss+=(stoi(t3)*4);
          }
          else if(t2.compare("resq") ==0){
             std::stringstream stream;
             stream<<uppercase<<setw(8)<<setfill('0')<<std::hex<<cnt_bss;
             insert_sym(&head,newNode(t1,stream.str()));
             cout<<"<res "<<setw(8)<<setfill('0')<<(stoi(t3)*8)<<">";
             cout<<"\t\t"<<t1<<" "<<t2<<" "<<t3<<endl;
             cnt_bss+=(stoi(t3)*8); 
          }
    }
    /*checking operand is lable or not*/
    int is_lbl(string lb,string colon){
       if(colon.compare(":")==0 && !isdigit(lb[0])){
         insert(&start,newNode(l,0,lb));
        return 1;
      }

      return 0;
    }
    /*checking instruction of register to register*/
    int reg_reg(string instr,string reg){
        int p = reg.find(",");
        int r1 = is_reg(reg.substr(0,p));
        int r2 = is_reg(reg.substr(p+1));
        mod_r_rm = "11";
             
           if(r1!=-1 && r2!=-1){
              mod_r_rm+=toBin(r2);
              mod_r_rm+=toBin(r1);
            
              cout<<uppercase<<setfill('0')<<setw(8)<<hex<<cnt_text<<"  ";
              if(_reg(reg.substr(0,p)) == 16)
              {
                cout<<"66";
                cnt_text++;
                insert(&start,newNode(l,3,"NA"));
              }
              else
                 insert(&start,newNode(l,2,"NA"));
              
              cout<<instr_rtor(instr,reg.substr(0,p),reg.substr(p+1))<<toHex(mod_r_rm.substr(0,4))
              <<toHex(mod_r_rm.substr(4))<<" ";
              cout<<"\t\t\t"<<instr<<" "<<reg<<endl;
              cnt_text+=2;

              return 1;
           }
          
           mod_r_rm.clear();
        
        return 0;
    }
   /*checking operand contain dword array*/
    int contain(string v){
      string word = "dword";
      for(int i=0;i<5;i++){
         if(v[i] != word[i])
          return 0;
      }

      return 1;
    }
    /*return big indian address*/ 
    string bigIndian(string addr){
      string return_addr="";
       for(int i=addr.length()-1;i>=0;i=i-2){
      
        if((i-1)>=0 && i>0){
           return_addr.push_back(addr[i-1]);
           return_addr.push_back(addr[i]);
        }
        else if(i>=0){
          return_addr.push_back('0');
          return_addr.push_back(addr[i]);
        }
       }
          
       return return_addr;
    }
    /*checking the operand is numeric type*/
    int is_num(string no){
       for(int i=0;i<no.length();i++){
          if(!isdigit(no[i]))
           return 0; 
       }
       return 1;
    }
    /*checking operand is symbol & also check in list available symbol*/
    string is_sym(string s){
      struct sym *t;
      for(t=head;t!=NULL;t=t->next){
         if(t->s == s)
          return t->addr;
      }
      return string("");
    }
    /*checking instruction type of register to immidiate*/
    int reg_imm(string instr,string imm){
        
        int p = imm.find(",");
        string reg = imm.substr(0,p);
        string v = imm.substr(p+1);
        int r1 = is_reg(reg);
        stringstream stream;
        string s = is_sym(v);
            
            if((r1 !=-1 && is_hex(v)!=0) || (r1!=-1 && is_num(v)!=0) || (r1!=-1 && s.length()!=0))
            {
              cout<<uppercase<<right<<setfill('0')<<setw(8)<<hex<<cnt_text<<"  ";
              mod_r_rm = "11";

                if(instr == "add"){
                  mod_r_rm+="000";
                }
                else if(instr == "or"){
                  mod_r_rm+="001"; 
                }
                else if(instr == "adc"){
                  mod_r_rm+="010";
                }
                else if(instr == "sbb"){
                  mod_r_rm+="011";
                }
                else if(instr == "and"){
                  mod_r_rm+="100";
                }
                else if(instr == "sub"){
                  mod_r_rm+="101";
                }
                else if(instr == "xor"){
                  mod_r_rm+="110";
                }
                else if(instr == "cmp"){
                  mod_r_rm+="111";
                }  
                     mod_r_rm+=toBin(r1);
                     
                     int rgv = _reg(reg);
                     if(rgv == 16){
                      cout<<"66";
                      cnt_text+=1; 
                     }
                     
                     if(is_hex(v)){
                        v.pop_back();
                        cout<<instr_rtoimm(instr,reg,hex_deci(v));
                        if(v.length() <=2)
                        {
                           if(reg!="eax" || reg != "al")
                           cout<<toHex(mod_r_rm.substr(0,4))<<toHex(mod_r_rm.substr(4));
                           cout<<setw(2)<<setfill('0')<<bigIndian(v);
                           cnt_text+=3;
                           if(rgv == 16)
                            insert(&start,newNode(l,4,"NA"));
                           else
                            insert(&start,newNode(l,3,"NA"));
                        }
                        else if(v.length() >2)
                        {
                           if(reg!="eax" || reg != "al")
                           cout<<toHex(mod_r_rm.substr(0,4))<<toHex(mod_r_rm.substr(4));
                           cout<<setw(8)<<setfill('0')<<bigIndian(v);
                           cnt_text+=6;
                           if(rgv == 16)
                            insert(&start,newNode(l,7,"NA"));
                           else
                            insert(&start,newNode(l,6,"NA"));
                        }

                     }
                     else if(is_num(v)){
                       stream<<uppercase<<std::hex<<stol(v);
                       cout<<instr_rtoimm(instr,reg,hex_deci(v));
                       cout<<toHex(mod_r_rm.substr(0,4))<<toHex(mod_r_rm.substr(4));
                        if(stream.str().length() <=2)
                        {
                           cout<<setw(2)<<setfill('0')<<bigIndian(stream.str());
                           cnt_text+=3;
                           if(rgv == 16)
                            insert(&start,newNode(l,4,"NA"));
                           else
                            insert(&start,newNode(l,3,"NA"));
                        }
                        else if(stream.str().length() >2)
                        {
                           cout<<setw(8)<<setfill('0')<<bigIndian(stream.str());
                           cnt_text+=6;
                           if(rgv == 16)
                            insert(&start,newNode(l,7,"NA"));
                           else
                            insert(&start,newNode(l,6,"NA"));
                        }
                     }
                     else if(s.length()!=0){
                           

                           if(_reg(reg) == 16){
                             cout<<"66"<<instr_rtoimm(instr,reg,257);
                             cout<<"["<<setw(4)<<s<<"]";
                             cnt_text+=4;
                             insert(&start,newNode(l,5,"NA"));
                             
                           }
                           else if(reg == "al"){ 
                            cout<<instr_rtoimm(instr,reg,8);
                            cout<<"["<<setw(2)<<s<<"]";
                            cnt_text+=2;
                            insert(&start,newNode(l,2,"NA"));
                           }
                           else if(reg == "eax"){
                            cout<<instr_rtoimm(instr,reg,68000);
                            cout<<"["<<s<<"]";
                            cnt_text+=6; 
                            insert(&start,newNode(l,6,"NA"));
                           }
                           else
                           {
                            cout<<instr_rtoimm(instr,reg,68000);
                            if(reg!="eax" || reg != "al" )
                            cout<<toHex(mod_r_rm.substr(0,4))<<toHex(mod_r_rm.substr(4));
                            cout<<"["<<s<<"]";
                            cnt_text+=6;
                            insert(&start,newNode(l,6,"NA"));
                           }

                           
                     }
                      cout<<"\t\t"<<instr<<" "<<imm<<endl;
                 return 1;   
            } 
            
           return 0;  
    }
    /*checking instructor type of register to memory*/
    int reg_mem(string instr,string mem){
      
       int p = mem.find(",");
       string v = mem.substr(p+1);
         
       if(contain(v)){
        v.erase(0,6);
        v.pop_back();
       } 
       else if(v.length()>2){
        v.erase(0,1);
        v.pop_back();
       }
        string reg = mem.substr(0,p);
        int r1 = is_reg(reg);
        int r2 = is_reg(v);
        string addr = is_sym(v);

           if(r1!=-1 && r2!=-1){
             mod_r_rm = "00";
             mod_r_rm+=toBin(r1);
             mod_r_rm+=toBin(r2);
                             
              cout<<uppercase<<setfill('0')<<setw(8)<<hex<<cnt_text<<"  ";
              if(_reg(reg) == 16){
                     cout<<"66";
                     cnt_text++;
                     insert(&start,newNode(l,3,"NA"));
              }
              else 
                insert(&start,newNode(l,2,"NA"));
              cout<<instr_rtom(instr,mem.substr(0,p),v);
              cout<<toHex(mod_r_rm.substr(0,4))<<toHex(mod_r_rm.substr(4))<<" ";
              cout<<"\t\t\t"<<instr<<" "<<mem<<endl;
              cnt_text+=2;

              return 1;
           }
           else if(r1!=-1 && is_num(v)){
             mod_r_rm = "00";
             mod_r_rm+=toBin(r1);
             mod_r_rm+="101";
            
              cout<<uppercase<<right<<setfill('0')<<setw(8)<<hex<<cnt_text<<"  ";
              cout<<toHex(mod_r_rm.substr(0,4))<<toHex(mod_r_rm.substr(4));
              std::stringstream stream;
              if(_reg(reg) == 16){
                     cout<<"66";
                     cnt_text++;
                     insert(&start,newNode(l,7,"NA"));
              }
              else
                insert(&start,newNode(l,6,"NA"));
              cout<<instr_rtom(instr,mem.substr(0,p),v);
              stream<<uppercase<<std::hex<<stoi(v);
              cout<<setw(8)<<setfill('0')<<left<<bigIndian(stream.str());
              cout<<"\t\t"<<instr<<" "<<mem<<endl;
              cnt_text+=6;
              
              return 1;
           }
           else if(r1!=-1 && is_hex(v)){
             mod_r_rm = "00";
             mod_r_rm+=toBin(r1);
             mod_r_rm+="101";
             v.pop_back();
              
              cout<<uppercase<<setfill('0')<<setw(8)<<hex<<cnt_text<<"  ";
              if(_reg(reg) == 16){
                     cout<<"66";
                     cnt_text++;
                     insert(&start,newNode(l,7,"NA"));
              }
              else
                insert(&start,newNode(l,6,"NA"));
              cout<<instr_rtom(instr,mem.substr(0,p),to_string(hex_deci(v)));
              cout<<toHex(mod_r_rm.substr(0,4))<<toHex(mod_r_rm.substr(4));
              cout<<uppercase<<left<<setfill('0')<<setw(8)<<bigIndian(v); 
              cout<<"\t\t"<<instr<<" "<<mem<<endl;
              cnt_text+=6;
               
              return 1;
           }
           else if(r1!=-1 && addr.length()!=0){
             mod_r_rm = "00";
             mod_r_rm+=toBin(r1);
             mod_r_rm+="101";
              

              cout<<uppercase<<setfill('0')<<setw(8)<<hex<<cnt_text<<"  ";
              if(_reg(reg) == 16){
                     cout<<"66";
                     cnt_text++;
                     insert(&start,newNode(l,7,"NA"));
              }  
              else
                   insert(&start,newNode(l,6,"NA"));   
               if(_reg(mem.substr(0,p)) == 8)
                cout<<instr_rtom(instr,mem.substr(0,p),"8");
               if(_reg(mem.substr(0,p)) == 16)
                cout<<instr_rtom(instr,mem.substr(0,p),"280");
               if(_reg(mem.substr(0,p)) == 32)
                cout<<instr_rtom(instr,mem.substr(0,p),"68000");
              cout<<toHex(mod_r_rm.substr(0,4))<<toHex(mod_r_rm.substr(4));
              cout<<"["<<addr<<"]"; 
              cout<<"\t\t"<<instr<<" "<<mem<<endl;
              cnt_text+=6;
               
              return 1;
           }

           mod_r_rm.clear();
       return 0;    
    }
    
 
};
/*driver code*/
int main(int argc, char const *argv[])
{
	translator t; //object of translator class
  /*variable declaration*/
  FILE *fp;
  string fname;
  char t1[20],t2[20],buff[80];

  cout<<"\nEnter the .asm file name:";
  cin>>fname;

  fp = fopen(fname.c_str(),"r");
  //checking file pointer null or not
  if(fp == NULL)
  {
    cout<<"invalid file read error";
    exit(0);
  }
   
  t.readL(fp); //try to translating each line of file
  
  return 0;
}