/*required header file*/
using namespace std;
#include<iostream>
#include<string>
#include<vector>
#include<iomanip>
#include<algorithm>
#include<cmath>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>
/*defination of literal class for collecting meaningful information & defination
 of various methods also variable*/
class literal{
 
   public :
    /*required variable declaration*/
    string _8bit[8] ={"al","cl","dl","bl","ah","ch","dh","bh"};
  	string _16bit[8] = {"ax","cx","dx","bx","sp","bp","si","di"};
  	string _32bit[8] = {"eax","ecx","edx","ebx","esp","ebp","esi","edi"};
   /*declaration of li type of structure*/
   struct lit{
      string literal;
      int addr; 
      lit *next;
   }*li;
   /*public constructor of literal class for initilizing object*/
   literal(){
   	initL(&li);
   }
   /*initilize lit type of structure to null*/
   void initL(struct lit **l){
   	*l = NULL;
   }
   /*creating lit type of structure node*/
   struct lit * litNode(string li,int addr){
   	 struct lit *N ;
     N=new lit;
   	 N->literal = li;
   	 N->addr = addr;
   	 N->next = NULL;

   	 return N;
   }
   /*creating list of symbol*/
   lit * createLit(lit *li,lit *N){
     struct lit *t;
   	 if(li == NULL)
   	 	li = N;
     else {
     	for(t=li;t->next!=NULL;t=t->next);
     		t->next = N;
     }
   }
   /*converting hex to decimal*/
   string toHex(string no){
      int p=0;
      int x =0;
      for(int i=no.length()-1;i>=0;i--){
          x += pow(2,p++)*(no[i]-'0');
      }
      if(x == 10)
        /*associate value of hex*/
      	return string("a");
      else if(x == 11)
      	return string("b");
      else if(x == 12)
      	return string("c");
      else if(x == 13)
      	return string("d");
      else if(x == 14)
      	return string("e");
      else if(x == 15)
      	return string("f");

      return string(to_string(x));//return hex string
   }   
   /*checking operand is register or not*/
   int is_reg(string r){

   	  for(int i=0;i<8;i++){
          if(_8bit[i] == r)
          	return i;
          else if(_16bit[i] == r)
          	return i;
          else if(_32bit[i] == r)
          	return i;
   	  }

   	  return -1;
   }
   /*checking opernd is hex value*/
   int is_hex(string s){
      if(s.back() == 'h' || s.back() == 'H')
      return 1;

     return 0;    
   }
   /*display literal table*/
   void dispLit(){
   	 struct lit *t;
     cout<<"\n\n#Litteral table"<<endl;
     cout<<"literal\tliteral address"<<endl;
     cout<<"............................................."<<endl;
   	 for(t=li;t!=NULL;t=t->next)
   	 	cout<<t->literal<<"\t"<<std::hex<<t->addr<<endl;
   }

};
/*defination of symbol class to collecting meaningful information also various method & variable
 declaration*/
class symbol : public literal
{
  private :
  /*declaration of variable*/
    int f ;
    int cnt_bss,cnt_data,cnt_text;
    char buff[80];
    char t1[10],t2[10],t3[80];
    
  public :
  /*declaration of structure for collecting symbol*/
    struct symbol_record{
         string name;
         int addr;
         string section;
         string type;
         string value;
         int size;
         char d_u;
       struct symbol_record *next;  
    }*h;
  /*public constructor of symbol class for initilizing object*/
  symbol(){
  	f = 0;
  	cnt_bss = 0;
  	cnt_data = 0;
  	cnt_text = 0;
  	init(&h);
  }    
  /*init() for initilize object to null*/
  void init(symbol_record **h){
  	*h = NULL;
  }
  /*creating node for storing symbol & all information*/
  struct symbol_record * newNode(string name,int addr,string section,string type,string v,int sz,char d){
     struct symbol_record *N;
     N = new symbol_record;
     N->name = name;
     N->addr = addr;
     N->section = section;
     N->type = type;
     N->value = v;
     N->size = sz;
     N->d_u = d;
     N->next = NULL;
         
   return N;
  }
  /*creating list of symbols*/
  struct symbol_record * create_record(struct symbol_record *h,struct symbol_record *N){
       symbol_record *t;
          if(h == NULL){
            h = N;
          }
          else{
             for(t=h;t->next!=NULL;t=t->next);
             t->next = N;
          }
          
     return h;     
  }
  /*read file lineby line*/
  void readFile(FILE *fp){
    
    while(fgets(buff,80,fp)!=NULL){
      //clear the string array
      memset(t1,'\0',sizeof(t1));
      memset(t2,'\0',sizeof(t2));
      memset(t3,'\0',sizeof(t3));
    	sscanf(buff,"%s %s %s",t1,t2,t3);
    	/*check each section of file*/
    	if(strcmp(t1,"section")==0 && strcmp(t2,".data")==0){
    		f = 1;
    		continue;
    	}
      if(strcmp(t1,"section")==0 && strcmp(t2,".bss")==0){
        	f = 2;
        	continue;
      }
      if(strcmp(t1,"section")==0 && strcmp(t2,".text")==0){
    		f = 3;
    		continue;
    	}
          /*according to section call the method*/
    	if(f == 1){
    		if(strlen(t3) != 0)
            {
                 is_const(t1,t2,t3);
            }
    	}
    	else if(f == 2){
            if(strlen(t3) != 0)
            {
                 is_variable(t1,t2,t3);
            }
    	}
    	else if(f == 3){
                
             if(strlen(t1)!=0 && strlen(t2)!=0){
                 /*checking instruction is lable or not*/
                 	if(is_lbl(t1,t2))
                 	{
                 		
                      struct symbol_record *newnode;
                      newnode = newNode(t1,cnt_text,"Text","Lable","NA",0,'D');	
                      h = create_record(h,newnode);

                      memset(t2,'\0',sizeof(t2));
                      memset(t3,'\0',sizeof(t3));
                      if(fgets(buff,80,fp)!=0){

                       sscanf(buff,"%s %s",t1,t2);
                       /*checking each instruction type*/
                          if(reg_to_reg(t2))
                          	cnt_text+=3;
                          else if(jmp_instr(t1,t2));

                          else if(reg_to_imm(t2));
                         
                          else if(reg_to_mem(t2));

                      }

                 	}
                  /*checking instructor type*/
                 	else if(reg_to_reg(t2)){
                 		cnt_text+=3;
                 	}
                 	else if(reg_to_imm(t2));
                 
                 	else if(reg_to_mem(t2));
             }
    	}
            
    }    
  }
 /*checking the opernd is lable or not*/
  int is_lbl(string l,string colon){

      if(colon == ":"){
      	for(int i=0;i<l.size();i++)
      	{
      		if(!isalpha(l[i]))
      			return 0;
      	}
      	return 1;
      }
    
    return 0;
  }
  /*checking opernd is decimal*/
  int is_int(string no){
       for(int i=0;i<no.size();i++){
       	 if(!isdigit(no[i]))
       	 	return 0;
       }
      return 1; 
  }
  /*checking instruction is that jump instruction*/
  int jmp_instr(string instr,string oprnd){

  	if(instr=="jmp" || instr=="jz" || instr=="jnz" && instr=="push" && is_reg(oprnd)!=-1)
           return 1;	
  	else if(is_hex(oprnd)!=0)
           return 1;   
    else if(instr=="jmp" || instr=="jz" || instr=="jnz" && instr=="push" && is_int(oprnd)!=0){
    	  cnt_text+=8;
    	  return 1;
    }
    else if(instr=="jmp" || instr=="jz" || instr=="jnz" && instr=="push" && is_record_sym(oprnd)!=0){
    	  cnt_text+=8;
    	  return 1;
    }       
       return 0;
  }
  /*checking instruction is register to register type*/
  int reg_to_reg(string rg){
     int p = rg.find(',');
    
        if(is_reg(rg.substr(0,p))!=-1 && is_reg(rg.substr(p+1))!=-1){
        	return 1;
        }
    return 0;    
  }
  /*checking dword memory*/
  int contains(string v)
  {
     string word="dword";
     int f = 0;
       for(int i=0;i<word.size();i++)
       {
          if(v[i] == word[i])
            f = 1;
          else
          {
            f = 0;
            break;
          }
       }

       return f;
  }
  /*checking the instruction is register to memory*/
  int reg_to_mem(string rm){
       int p = rm.find(',');
       string v = rm.substr(p+1);
       struct lit *N;
        if(contains(v)>0)
        {
            v.erase(0,6);
            v.pop_back();
        }
        else if(v.size() >2){
       	 v.erase(0,1);
       	 v.pop_back();
       }
       /*register to register memory type instruction*/
         if(is_reg(rm.substr(0,p))!=-1 && is_reg(v)!=-1)
         {
         	 N = litNode(rm,cnt_text);
             li = createLit(li,N);
         	 cnt_text+=3;
             return 1;
         }
         /*register to symbol memory instruction*/
         else if(is_reg(rm.substr(0,p))!=-1 && is_record_sym(v)!=0){
            N = litNode(rm,cnt_text);
            li = createLit(li,N);
            cnt_text+=5;
            return 1;
         }
         /*register to hex memory instruction*/
         else if(is_reg(rm.substr(0,p))!=-1 && is_hex(v)!=0){
           N = litNode(rm,cnt_text);
           li = createLit(li,N);
         	if(strlen(v.c_str())==3 || strlen(v.c_str())==2){
             cnt_text+=3;
      	    }
      	    else if(strlen(v.c_str())>3){
            cnt_text+=5;
      	    }
      	    return 1;
         }

     return 0;
  }
  /*checking symbol is present in list or not*/
  int is_record_sym(string s){
     symbol_record *t;
     for(t=h;t!=NULL;t=t->next){
     	if(t->name == s)
     		return 1;
     }
     return 0;
  }
  /*checking instruction register to immidiate*/
  int reg_to_imm(string rimm){
    int p = rimm.find(',');
    string v = rimm.substr(p+1);
    struct lit *N;
      /*checking instruction register to hexadecimal*/
     if(is_reg(rimm.substr(0,p))!=-1 && is_hex(rimm.substr(p+1))!=0){
      	  N = litNode(rimm,cnt_text);
          li = createLit(li,N);
                              
      	  if(strlen(v.c_str())==3 || strlen(v.c_str())==2){
             cnt_text+=3;
      	  }
      	  else if(strlen(v.c_str())>3){
            cnt_text+=5;
      	  }

      	  return 1;
      }  
      /*checking instruction register to decimal*/
     else if(is_reg(rimm.substr(0,p))!=-1 && is_int(v)!=0){
          
          N = litNode(rimm,cnt_text);
          li = createLit(li,N);

          if(strlen(v.c_str())==2 || strlen(v.c_str())==1){
             cnt_text+=3;
      	  }
      	  else if(strlen(v.c_str())>2){
             cnt_text+=5;
      	  }

      	  return 1;
     }   
     return 0;
  }
  /*collecting the constant from .data section*/
  void is_const(string s1,string s2,string s3){
      struct symbol_record *newnode;
        
         if(s2 == "db"){
           newnode = newNode(s1,cnt_data,"Data","Byte",s3,strlen(s3.c_str())-2,'D');	
           h = create_record(h,newnode);
           cnt_data+=s3.size()-2;
         }
         if(s2 == "dw"){
           newnode = newNode(s1,cnt_data,"Data","Word",s3,2,'D');	
           h = create_record(h,newnode);
           cnt_data+=2;
         }  
         if(s2 == "dd"){
           newnode = newNode(s1,cnt_data,"Data","Double",s3,4,'D');	
           h = create_record(h,newnode);
           cnt_data+=4;
         }
         if(s2 == "dq"){
           newnode = newNode(s1,cnt_data,"Data","Quad",s3,8,'D');	
           h = create_record(h,newnode);
           cnt_data+=8;
         }

  }
  /*collecting the variable in .bss section*/
  void is_variable(string s1,string s2,string s3){
        struct symbol_record *newnode;
        
         if(s2 == "resb"){
           newnode = newNode(s1,cnt_bss,"Bss","Byte","NA",atoi(s3.c_str()),'D');	
           h = create_record(h,newnode);
           cnt_bss+=atoi(s3.c_str());
         }
         if(s2 == "resw"){
           newnode = newNode(s1,cnt_bss,"Bss","Word","NA",atoi(s3.c_str())*2,'D');	
           h = create_record(h,newnode);
           cnt_bss+=(2*atoi(s3.c_str()));
         }  
         if(s2 == "resd"){
           newnode = newNode(s1,cnt_bss,"Bss","Double","NA",atoi(s3.c_str())*4,'D');	
           h = create_record(h,newnode);
           cnt_bss+=(4*atoi(s3.c_str()));
         }
         if(s2 == "resq"){
           newnode = newNode(s1,cnt_bss,"Bss","Quad","NA",atoi(s3.c_str())*8,'D');	
           h = create_record(h,newnode);
           cnt_bss+=(8*atoi(s3.c_str()));
         }

  }
  /*display symbol table*/
  void disp(){
  	symbol_record *node;
    cout<<"#symbol table"<<endl;
    cout<<"Name\tAddress\tSection\tType\tValue\tSize\tDefine/Undefine"<<endl;
    cout<<".........................................................................................."<<endl;
  	for(node=h;node!=NULL;node=node->next){
           	cout<<node->name<<"\t"<<std::hex<<node->addr<<"\t"<<node->section<<"\t"
           <<node->type<<"\t"<<node->value<<"\t"<<node->size<<"\t"<<node->d_u<<endl;
    }
   dispLit();
  }
  
  /*combine and collect lables of .data section*/ 
  void concate_sym_data(symbol s[],int n)
  {
     int p = 0;
     struct symbol_record *t;
     std::vector <string> v;
     std::vector <string>::iterator it;

     cout<<"Name\tAddress\tSection\tType\tValue\tSize\tDefine/Undefine"<<endl;
     cout<<"......................................................................................."<<endl;
       for(t = s[0].h;t!=NULL;t=t->next)
       {
         if(t->section == "Data")
         {    
          cout<<t->name<<"\t"<<std::hex<<t->addr<<"\t"<<t->section<<"\t"<<t->type<<"\t"
          <<t->value<<"\t"<<t->size<<"\t"<<t->d_u<<endl;
          cnt_data+=t->size; 
          v.push_back(t->name);
         }
         
       }
        
           for(int i=1;i<n;i++)
           {
               for(t = s[i].h;t!=NULL;t=t->next)
               {
                 if(t->section == "Data")
                 {
                 it = std::find(v.begin(),v.end(),t->name);
                 p = v.size()-1;
                   if(v[p] == t->name)
                   {
                    cout<<t->name+"_abc"<<"\t"<<std::hex<<cnt_data<<"\t"<<t->section<<"\t"
                    <<t->type<<"\t"<<t->value<<"\t"<<t->size<<"\t"<<t->d_u<<endl;
                    cnt_data+=t->size;
                   }
                   else if(it != v.end())
                   {
                    cout<<t->name+"_abc"<<"\t"<<std::hex<<cnt_data<<"\t"<<t->section<<"\t"
                    <<t->type<<"\t"
                    <<t->value<<"\t"<<t->size<<"\t"<<t->d_u<<endl;
                    cnt_data+=t->size;
                   }
                   else
                   {
                    cout<<t->name<<"\t"<<std::hex<<cnt_data<<"\t"<<t->section<<"\t"<<t->type<<"\t"
                    <<t->value<<"\t"<<t->size<<"\t"<<t->d_u<<endl;
                    cnt_data+=t->size;
                    v.push_back(t->name);
                   }

                 }

              }
              
           }
  }
 /*combine and collect lables of .bss section*/ 
  void concate_sym_bss(symbol s[],int n)
  {
     int p = 0;
     struct symbol_record *t;
     std::vector <string> v;
     std::vector <string>::iterator it;

       for(t = s[0].h;t!=NULL;t=t->next)
       {
         if(t->section == "Bss")
         {    
          cout<<t->name<<"\t"<<std::hex<<t->addr<<"\t"<<t->section<<"\t"<<t->type<<"\t"
          <<t->value<<"\t"<<t->size<<"\t"<<t->d_u<<endl;
          cnt_bss+=t->size; 
          v.push_back(t->name);
         }
         
       }
        
           for(int i=1;i<n;i++)
           {
               for(t = s[i].h;t!=NULL;t=t->next)
               {
                 if(t->section == "Bss")
                 {
                 it = std::find(v.begin(),v.end(),t->name);
                 p = v.size()-1;
                   if(v[p] == t->name)
                   {
                    cout<<t->name+"_abc"<<"\t"<<std::hex<<cnt_bss<<"\t"<<t->section<<"\t"
                    <<t->type<<"\t"<<t->value<<"\t"<<t->size<<"\t"<<t->d_u<<endl;
                    cnt_bss+=t->size;
                   }
                   else if(it != v.end())
                   {
                    cout<<t->name+"_abc"<<"\t"<<std::hex<<cnt_bss<<"\t"<<t->section<<"\t"
                    <<t->type<<"\t"<<t->value<<"\t"<<t->size<<"\t"<<t->d_u<<endl;
                    cnt_bss+=t->size;
                   }
                   else
                   {
                    cout<<t->name<<"\t"<<std::hex<<cnt_bss<<"\t"<<t->section<<"\t"<<t->type<<"\t"
                    <<t->value<<"\t"<<t->size<<"\t"<<t->d_u<<endl;
                    cnt_bss+=t->size;
                    v.push_back(t->name);
                   }

                 }

              }
              
           }
   }
   /*combine and collect lables of .text section*/ 
   void concate_sym_text(symbol s[],int n)
   {
     int p = 0;
     struct symbol_record *t;
     std::vector <string> v;
     std::vector <string>::iterator it;

       for(t = s[0].h;t!=NULL;t=t->next)
       {
         if(t->section == "Text")
         {    
          cout<<t->name<<"\t"<<std::hex<<t->addr<<"\t"<<t->section<<"\t"<<t->type<<"\t"
          <<t->value<<"\t"<<t->size<<"\t"<<t->d_u<<endl;
          cnt_text+=t->size; 
          v.push_back(t->name);
         }
         
       }
        
           for(int i=1;i<n;i++)
           {
               for(t = s[i].h;t!=NULL;t=t->next)
               {
                 if(t->section == "Text")
                 {
                 it = std::find(v.begin(),v.end(),t->name);
                 p = v.size()-1;
                   if(v[p] == t->name)
                   {
                    cout<<t->name+"_abc"<<"\t"<<std::hex<<cnt_text<<"\t"<<t->section<<"\t"
                    <<t->type<<"\t"<<t->value<<"\t"<<t->size<<"\t"<<t->d_u<<endl;
                    cnt_text+=t->size;
                   }
                   else if(it != v.end())
                   {
                    cout<<t->name+"_abc"<<"\t"<<std::hex<<cnt_text<<"\t"<<t->section<<"\t"
                    <<t->type<<"\t"<<t->value<<"\t"<<t->size<<"\t"<<t->d_u<<endl;
                    cnt_text+=t->size;
                   }
                   else
                   {
                    cout<<t->name<<"\t"<<std::hex<<cnt_text<<"\t"<<t->section<<"\t"<<t->type<<"\t"
                    <<t->value<<"\t"<<t->size<<"\t"<<t->d_u<<endl;
                    cnt_text+=t->size;
                    v.push_back(t->name);
                   }

                 }

              }
              
           }
  }
};
/*driver code*/
int main(int argc, char const *argv[])
{
	/*declaration of variable*/
  FILE **fp;
  symbol *s;
  string fname;
  int n;
	system("clear");
  /*array of file discriptor*/
  cout<<"Enter the no of files :";
  cin>>n;
  fp =(FILE**)malloc(n*sizeof(FILE **));
  s = new symbol[n+1];
  //reading n files
  for(int i=0;i<n;i++){
    cout<<"\nEnter the file name :";
    cin>>fname;
    fp[i] = fopen(fname.c_str(),"r");
      if(fp[i] == NULL){
       cout<<"error to opening file";
       exit(0);
      }
      s[i].readFile(fp[i]);
      s[i].disp();
   }
       /*combine two or more symbol table together & dispaly*/
      cout<<"\n\n#combine symbol table"<<endl;
      s[n].concate_sym_data(s,n);
      s[n].concate_sym_bss(s,n);    
      s[n].concate_sym_text(s,n);  

	return 0;
}